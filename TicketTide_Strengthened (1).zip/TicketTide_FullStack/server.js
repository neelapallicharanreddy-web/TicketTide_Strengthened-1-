require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Database = require("better-sqlite3");
const nodemailer = require("nodemailer");
const Razorpay = require("razorpay");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const QRCode = require("qrcode");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const logDir=process.env.LOG_DIR || path.join(__dirname,"logs");
fs.mkdirSync(logDir,{recursive:true});
const logFile=path.join(logDir,"application.log");
const logger={
  info:(data,message)=>writeLog("INFO",data,message),
  warn:(data,message)=>writeLog("WARN",data,message),
  error:(data,message)=>writeLog("ERROR",data,message)
};
function writeLog(level,data,message){
  const safe={...(data||{})}; if(safe.err instanceof Error) safe.err={name:safe.err.name,message:safe.err.message,stack:safe.err.stack}; const entry={timestamp:new Date().toISOString(),level,message,...safe};
  const line=JSON.stringify(entry);
  (level==="ERROR"?process.stderr:process.stdout).write(line+"\n");
  fs.appendFileSync(logFile,line+"\n");
}

const db = new Database(process.env.DB_FILE || path.join(__dirname,"tickettide.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"1mb"}));
app.use((req,res,next)=>{
  const started=Date.now(); req.requestId=crypto.randomUUID();
  res.setHeader("X-Request-Id",req.requestId);
  res.on("finish",()=>logger.info({requestId:req.requestId,method:req.method,path:req.path,status:res.statusCode,durationMs:Date.now()-started},"HTTP request"));
  next();
});
app.use(express.static(path.join(__dirname,"public")));
app.use("/api/auth",rateLimit({windowMs:15*60*1000,max:12,standardHeaders:true,legacyHeaders:false}));

db.exec(`
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,verified INTEGER NOT NULL DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS otps(email TEXT PRIMARY KEY,otp_hash TEXT NOT NULL,expires_at INTEGER NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,purpose TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS payments(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,razorpay_order_id TEXT UNIQUE NOT NULL,amount INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'created',items_json TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE IF NOT EXISTS tickets(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,payment_id TEXT NOT NULL,event_name TEXT NOT NULL,tier TEXT NOT NULL,face_value INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'active',created_at TEXT DEFAULT CURRENT_TIMESTAMP,scanned_at TEXT,FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(payment_id) REFERENCES payments(id));
CREATE TABLE IF NOT EXISTS qr_uses(jti TEXT PRIMARY KEY,ticket_id TEXT NOT NULL,expires_at INTEGER NOT NULL,used_at INTEGER,FOREIGN KEY(ticket_id) REFERENCES tickets(id));
CREATE TABLE IF NOT EXISTS transfers(id TEXT PRIMARY KEY,ticket_id TEXT NOT NULL,from_user TEXT NOT NULL,to_user TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(ticket_id) REFERENCES tickets(id));
CREATE TABLE IF NOT EXISTS resale_listings(id TEXT PRIMARY KEY,ticket_id TEXT NOT NULL,user_id TEXT NOT NULL,face_value INTEGER NOT NULL,price INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'listed',created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(ticket_id) REFERENCES tickets(id));
CREATE TABLE IF NOT EXISTS inventory(
 tier TEXT PRIMARY KEY, capacity INTEGER NOT NULL CHECK(capacity >= 0),
 available INTEGER NOT NULL CHECK(available >= 0), updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS inventory_reservations(
 id TEXT PRIMARY KEY, payment_id TEXT NOT NULL, tier TEXT NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity > 0), status TEXT NOT NULL DEFAULT 'reserved',
 expires_at INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(tier) REFERENCES inventory(tier)
);
CREATE INDEX IF NOT EXISTS idx_reservations_expiry ON inventory_reservations(status, expires_at);

`);

// Initial demo stock is inserted only once; existing inventory is never overwritten.
const seedInventory = db.prepare("INSERT OR IGNORE INTO inventory(tier,capacity,available) VALUES(?,?,?)");
seedInventory.run("early",100,100); seedInventory.run("general",200,200); seedInventory.run("vip",50,50);

const mailer = process.env.SMTP_HOST ? nodemailer.createTransport({
 host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:process.env.SMTP_SECURE==="true",
 auth:process.env.SMTP_USER?{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}:undefined
}) : null;
const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET ? new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET}) : null;
const jwtSecret=process.env.JWT_SECRET, qrSecret=process.env.QR_SIGNING_SECRET;
const priceMap={early:799,general:1299,vip:2499};
const tierNames={early:"Early Bird",general:"General Admission",vip:"VIP Backstage"};
function calculateOrderTotals(items) {
  if(!Array.isArray(items)||!items.length) throw new Error("Select at least one ticket.");
  let subtotal=0,count=0;
  for(const item of items){
    if(!priceMap[item.tier]||!Number.isInteger(item.quantity)||item.quantity<1||item.quantity>6)
      throw new Error("Invalid ticket tier or quantity. Maximum 6 per tier.");
    subtotal+=priceMap[item.tier]*item.quantity; count+=item.quantity;
  }
  const fee=count*30,tax=Math.round(subtotal*.05);
  return {subtotal,count,fee,tax,amount:subtotal+fee+tax};
}
const allowedEmail=e=>/@[^@]+\.(edu|ac\.in)$/i.test(e);
const hash=s=>crypto.createHash("sha256").update(s).digest("hex");
function requireConfig(){if(!jwtSecret||jwtSecret.length<32)throw new Error("JWT_SECRET must be set to a random string of at least 32 characters.");if(!qrSecret||qrSecret.length<32)throw new Error("QR_SIGNING_SECRET must be set to a random string of at least 32 characters.");}
function auth(req,res,next){try{requireConfig();const h=req.headers.authorization||"";const t=h.startsWith("Bearer ")?h.slice(7):"";const payload=jwt.verify(t,jwtSecret);const user=db.prepare("SELECT id,name,email,verified FROM users WHERE id=?").get(payload.sub);if(!user||!user.verified)return res.status(401).json({error:"Verified student account required."});req.user=user;next();}catch(e){return res.status(401).json({error:e.message==="jwt expired"?"Session expired. Verify your email again.":"Authentication required."});}}
function sendMail(to,subject,text){if(!mailer)throw new Error("Email is not configured. Add SMTP settings to .env before using OTP verification.");return mailer.sendMail({from:process.env.MAIL_FROM||process.env.SMTP_USER,to,subject,text});}
function randomId(){return crypto.randomUUID();}
const RESERVATION_TTL_MS = 10 * 60 * 1000;
function reserveInventory(paymentId, items, now=Date.now()) {
  const tx = db.transaction(() => {
    // Expired unpaid holds return to stock atomically.
    const expired = db.prepare("SELECT id,tier,quantity FROM inventory_reservations WHERE status='reserved' AND expires_at<=?").all(now);
    const restore = db.prepare("UPDATE inventory SET available=available+?,updated_at=CURRENT_TIMESTAMP WHERE tier=?");
    for (const hold of expired) restore.run(hold.quantity, hold.tier);
    db.prepare("UPDATE inventory_reservations SET status='expired' WHERE status='reserved' AND expires_at<=?").run(now);
    const reserve = db.prepare("UPDATE inventory SET available=available-?,updated_at=CURRENT_TIMESTAMP WHERE tier=? AND available>=?");
    const insert = db.prepare("INSERT INTO inventory_reservations(id,payment_id,tier,quantity,expires_at) VALUES(?,?,?,?,?)");
    for (const item of items) {
      const result = reserve.run(item.quantity, item.tier, item.quantity);
      if (result.changes !== 1) throw new Error(`Insufficient inventory for ${item.tier}.`);
      insert.run(randomId(), paymentId, item.tier, item.quantity, now + RESERVATION_TTL_MS);
    }
  });
  tx.immediate();
}
function releaseReservations(paymentId, status='released') {
  const tx = db.transaction(() => {
    const rows = db.prepare("SELECT tier,quantity FROM inventory_reservations WHERE payment_id=? AND status='reserved'").all(paymentId);
    const restore = db.prepare("UPDATE inventory SET available=available+?,updated_at=CURRENT_TIMESTAMP WHERE tier=?");
    for (const row of rows) restore.run(row.quantity,row.tier);
    db.prepare("UPDATE inventory_reservations SET status=? WHERE payment_id=? AND status='reserved'").run(status,paymentId);
  });
  tx.immediate();
}

function createOtp(email,purpose){const otp=String(crypto.randomInt(100000,1000000));db.prepare("INSERT INTO otps(email,otp_hash,expires_at,attempts,purpose) VALUES(?,?,?,?,?) ON CONFLICT(email) DO UPDATE SET otp_hash=excluded.otp_hash,expires_at=excluded.expires_at,attempts=0,purpose=excluded.purpose").run(email,hash(otp),Date.now()+5*60*1000,0,purpose);return otp;}
app.get("/api/health",(req,res)=>{
  try { db.prepare("SELECT 1").get(); res.json({ok:true,service:"TicketTide API",database:"connected",payments:!!razorpay,email:!!mailer,uptimeSeconds:Math.floor(process.uptime())}); }
  catch(e){ logger.error({err:e},"Health check failed"); res.status(503).json({ok:false,database:"unavailable"}); }
});

app.post("/api/auth/send-otp",async(req,res)=>{try{const name=String(req.body.name||"Student").trim().slice(0,100),email=String(req.body.email||"").trim().toLowerCase();if(!allowedEmail(email))return res.status(400).json({error:"Use a valid .edu or .ac.in student email address."});const otp=createOtp(email,"login");await sendMail(email,"Your TicketTide verification code",`Hello ${name},\n\nYour TicketTide OTP is ${otp}. It expires in 5 minutes. Do not share it.\n`);res.json({message:"Verification OTP sent. Check your student email."});}catch(e){res.status(500).json({error:e.message});}});
app.post("/api/auth/verify-otp",(req,res)=>{try{requireConfig();const name=String(req.body.name||"Student").trim().slice(0,100),email=String(req.body.email||"").trim().toLowerCase(),otp=String(req.body.otp||"");const row=db.prepare("SELECT * FROM otps WHERE email=? AND purpose='login'").get(email);if(!row||row.expires_at<Date.now()||row.attempts>=5||row.otp_hash!==hash(otp)){if(row)db.prepare("UPDATE otps SET attempts=attempts+1 WHERE email=?").run(email);return res.status(400).json({error:"Invalid or expired OTP."});}db.prepare("DELETE FROM otps WHERE email=?").run(email);let user=db.prepare("SELECT * FROM users WHERE email=?").get(email);if(!user){const id=randomId();db.prepare("INSERT INTO users(id,name,email,verified) VALUES(?,?,?,1)").run(id,name,email);user=db.prepare("SELECT * FROM users WHERE id=?").get(id);}else{db.prepare("UPDATE users SET verified=1,name=? WHERE id=?").run(name,user.id);user=db.prepare("SELECT * FROM users WHERE id=?").get(user.id);}const token=jwt.sign({sub:user.id},jwtSecret,{expiresIn:"7d"});res.json({token,user:{id:user.id,name:user.name,email:user.email,verified:true}});}catch(e){res.status(500).json({error:e.message});}});

app.post("/api/payments/create-order",auth,async(req,res)=>{
  let paymentId;
  try {
    if(!razorpay)return res.status(503).json({error:"Razorpay is not configured. Add test API keys to .env."});
    const items=req.body.items;
    let totals;
    try { totals=calculateOrderTotals(items); }
    catch(validationError) { return res.status(400).json({error:validationError.message}); }
    const {amount}=totals;
    paymentId=randomId();
    // Reserve stock before creating a payment order; SQLite IMMEDIATE transaction
    // serializes competing buyers and the guarded UPDATE prevents negative stock.
    reserveInventory(paymentId,items);
    try {
      const order=await razorpay.orders.create({amount:amount*100,currency:"INR",receipt:"tt_"+Date.now(),notes:{userId:req.user.id}});
      db.prepare("INSERT INTO payments(id,user_id,razorpay_order_id,amount,items_json) VALUES(?,?,?,?,?)").run(paymentId,req.user.id,order.id,amount,JSON.stringify(items));
      res.json({keyId:process.env.RAZORPAY_KEY_ID,orderId:order.id,amount:order.amount,currency:order.currency,paymentId});
    } catch(error) {
      releaseReservations(paymentId);
      throw error;
    }
  } catch(e) {
    if(paymentId) { try { releaseReservations(paymentId); } catch(releaseError) { logger.error({err:releaseError,paymentId},"Failed to release inventory reservation"); } }
    if(e.message.startsWith("Insufficient inventory")) return res.status(409).json({error:e.message});
    logger.error({err:e,paymentId},"Payment order creation failed");
    res.status(500).json({error:"Unable to create payment order. Please try again."});
  }
});
app.post("/api/payments/verify",auth,(req,res)=>{
  try {
    const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body;
    if(!razorpay_order_id||!razorpay_payment_id||!razorpay_signature)return res.status(400).json({error:"Missing Razorpay verification fields."});
    const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET||"").update(`${razorpay_order_id}|${razorpay_payment_id}`).digest("hex");
    if(Buffer.byteLength(expected)!==Buffer.byteLength(String(razorpay_signature))||!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(String(razorpay_signature))))return res.status(400).json({error:"Payment signature verification failed."});
    const payment=db.prepare("SELECT * FROM payments WHERE razorpay_order_id=? AND user_id=?").get(razorpay_order_id,req.user.id);
    if(!payment)return res.status(404).json({error:"Payment order not found."});
    if(payment.status==="paid")return res.json({message:"Payment already verified."});
    const items=JSON.parse(payment.items_json);
    const tx=db.transaction(()=>{
      const changed=db.prepare("UPDATE payments SET status='paid' WHERE id=? AND status='created'").run(payment.id);
      if(changed.changes!==1)throw new Error("Payment is not in a payable state.");
      const reservations=db.prepare("SELECT tier,quantity FROM inventory_reservations WHERE payment_id=? AND status='reserved' AND expires_at>?").all(payment.id,Date.now());
      const reservedCount=reservations.reduce((n,r)=>n+r.quantity,0);
      if(reservedCount!==items.reduce((n,i)=>n+i.quantity,0))throw new Error("Inventory reservation expired. Payment needs reconciliation.");
      db.prepare("UPDATE inventory_reservations SET status='sold' WHERE payment_id=? AND status='reserved'").run(payment.id);
      const insert=db.prepare("INSERT INTO tickets(id,user_id,payment_id,event_name,tier,face_value) VALUES(?,?,?,?,?,?)");
      for(const item of items)for(let i=0;i<item.quantity;i++)insert.run(randomId(),req.user.id,payment.id,"Campus Music Fest 2026",tierNames[item.tier],priceMap[item.tier]);
    });
    tx.immediate();
    res.json({message:"Payment verified and tickets issued."});
  } catch(e) {
    logger.error({err:e,orderId:req.body.razorpay_order_id,userId:req.user.id},"Payment verification failed");
    res.status(500).json({error:"Payment verification failed. Contact support if your payment was charged."});
  }
});

app.get("/api/inventory",(req,res)=>{
  const stock=db.prepare("SELECT tier,capacity,available,(capacity-available) AS reservedOrSold FROM inventory ORDER BY tier").all();
  res.json({inventory:stock});
});

app.get("/api/tickets/mine",auth,(req,res)=>{const tickets=db.prepare("SELECT id,event_name AS eventName,tier,face_value AS faceValue,status,created_at AS createdAt FROM tickets WHERE user_id=? ORDER BY created_at DESC").all(req.user.id);res.json({user:{name:req.user.name,email:req.user.email},tickets});});
app.get("/api/tickets/:id/qr",auth,async(req,res)=>{try{const ticket=db.prepare("SELECT * FROM tickets WHERE id=? AND user_id=? AND status='active'").get(req.params.id,req.user.id);if(!ticket)return res.status(404).json({error:"Active ticket not found."});requireConfig();const now=Math.floor(Date.now()/1000),jti=randomId(),payload={tid:ticket.id,jti,iat:now,exp:now+30};const token=jwt.sign(payload,qrSecret,{algorithm:"HS256"});db.prepare("INSERT INTO qr_uses(jti,ticket_id,expires_at) VALUES(?,?,?)").run(jti,ticket.id,(now+30)*1000);const qrDataUrl=await QRCode.toDataURL(token,{width:220,margin:1,errorCorrectionLevel:"M"});res.json({qrDataUrl,token,tokenPreview:token.slice(0,18)+"…",expiresIn:30});}catch(e){res.status(500).json({error:e.message});}});

app.post("/api/transfers/send-otp",auth,async(req,res)=>{try{const email=String(req.body.email||"").trim().toLowerCase();if(!allowedEmail(email))return res.status(400).json({error:"Recipient must use a .edu or .ac.in student email."});const otp=createOtp(email,"transfer");await sendMail(email,"TicketTide ticket transfer verification",`Your ticket transfer OTP is ${otp}. It expires in 5 minutes.`);res.json({message:"Recipient verification OTP sent."});}catch(e){res.status(500).json({error:e.message});}});
app.post("/api/transfers/complete",auth,(req,res)=>{try{const email=String(req.body.email||"").trim().toLowerCase(),otp=String(req.body.otp||"");const row=db.prepare("SELECT * FROM otps WHERE email=? AND purpose='transfer'").get(email);if(!row||row.expires_at<Date.now()||row.attempts>=5||row.otp_hash!==hash(otp)){if(row)db.prepare("UPDATE otps SET attempts=attempts+1 WHERE email=?").run(email);return res.status(400).json({error:"Recipient OTP invalid or expired."});}let recipient=db.prepare("SELECT * FROM users WHERE email=?").get(email);if(!recipient){return res.status(400).json({error:"Recipient must verify their student email and create a TicketTide account first."});}const ticket=db.prepare("SELECT * FROM tickets WHERE id=? AND user_id=? AND status='active'").get(req.body.ticketId,req.user.id);if(!ticket)return res.status(404).json({error:"Active ticket not owned by sender."});const tx=db.transaction(()=>{db.prepare("UPDATE tickets SET user_id=? WHERE id=?").run(recipient.id,ticket.id);db.prepare("INSERT INTO transfers(id,ticket_id,from_user,to_user) VALUES(?,?,?,?)").run(randomId(),ticket.id,req.user.id,recipient.id);db.prepare("DELETE FROM otps WHERE email=?").run(email);});tx();res.json({message:"Ticket ownership transferred. A new QR pass will be generated for the recipient."});}catch(e){res.status(500).json({error:e.message});}});

app.post("/api/resale/list",auth,(req,res)=>{try{const face=Number(req.body.faceValue),price=Number(req.body.price);if(!Number.isInteger(face)||!Number.isInteger(price)||face<=0||price<=0)return res.status(400).json({error:"Enter valid whole-number prices."});if(price>face)return res.status(400).json({error:`Anti-Scalping Rule: Price Exceeds Face Value. Maximum allowed is ₹${face.toLocaleString("en-IN")}.`});const ticket=db.prepare("SELECT * FROM tickets WHERE user_id=? AND status='active' ORDER BY created_at DESC LIMIT 1").get(req.user.id);if(!ticket)return res.status(404).json({error:"No active ticket available to list."});if(face!==ticket.face_value)return res.status(400).json({error:"Submitted face value does not match the original ticket price."});const id=randomId();db.prepare("INSERT INTO resale_listings(id,ticket_id,user_id,face_value,price) VALUES(?,?,?,?,?)").run(id,ticket.id,req.user.id,face,price);res.json({message:"Price-cap validation passed. Listing created.",listingId:id});}catch(e){res.status(500).json({error:e.message});}});

app.post("/api/admin/scan",(req,res)=>{try{if(!process.env.ADMIN_API_KEY||req.headers["x-admin-key"]!==process.env.ADMIN_API_KEY)return res.status(401).json({error:"Organizer authorization failed."});requireConfig();const raw=String(req.body.token||"");const payload=jwt.verify(raw,qrSecret,{algorithms:["HS256"]});const use=db.prepare("SELECT * FROM qr_uses WHERE jti=? AND ticket_id=?").get(payload.jti,payload.tid);if(!use||use.used_at||use.expires_at<Date.now())return res.status(400).json({error:"QR code expired, already used, or invalid."});const ticket=db.prepare("SELECT * FROM tickets WHERE id=? AND status='active'").get(payload.tid);if(!ticket)return res.status(400).json({error:"Ticket inactive or already checked in."});const tx=db.transaction(()=>{const used=db.prepare("UPDATE qr_uses SET used_at=? WHERE jti=? AND ticket_id=? AND used_at IS NULL AND expires_at>=?").run(Date.now(),payload.jti,ticket.id,Date.now());if(used.changes!==1)throw new Error("QR code already used or expired.");const marked=db.prepare("UPDATE tickets SET status='used',scanned_at=CURRENT_TIMESTAMP WHERE id=? AND status='active'").run(ticket.id);if(marked.changes!==1)throw new Error("Ticket already checked in.");});tx();res.json({message:"Valid ticket. Entry approved; ticket marked as used.",ticketId:ticket.id});}catch(e){res.status(400).json({error:"Invalid, expired or malformed QR token."});}});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.use((req,res)=>res.status(404).json({error:"Route not found.",requestId:req.requestId}));
app.use((err,req,res,next)=>{
  logger.error({err,requestId:req.requestId,method:req.method,path:req.path},"Unhandled request error");
  if(res.headersSent)return next(err);
  res.status(500).json({error:"Internal server error.",requestId:req.requestId});
});
process.on("unhandledRejection",(reason)=>logger.error({err:reason},"Unhandled promise rejection"));
process.on("uncaughtException",(error)=>{logger.error({err:error},"Uncaught exception");process.exit(1);});
if(require.main===module){
  const server=app.listen(PORT,()=>logger.info({port:PORT},"TicketTide server started"));
  const shutdown=()=>server.close(()=>{db.close();process.exit(0);});
  process.on("SIGTERM",shutdown); process.on("SIGINT",shutdown);
}
module.exports={app,db,reserveInventory,releaseReservations,priceMap,calculateOrderTotals};

