const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "tickettide-unit-"));
process.env.DB_FILE = path.join(tempDir, "unit.sqlite");
const { calculateOrderTotals, priceMap } = require("../server");

test("ticket prices are defined for all supported tiers", () => {
  assert.deepEqual(priceMap, { early: 799, general: 1299, vip: 2499 });
});

test("order calculator applies convenience fee and 5 percent tax", () => {
  const result = calculateOrderTotals([{ tier: "early", quantity: 2 }]);
  assert.deepEqual(result, { subtotal: 1598, count: 2, fee: 60, tax: 80, amount: 1738 });
});

test("order calculator rejects unknown tiers and invalid quantities", () => {
  assert.throws(() => calculateOrderTotals([{ tier: "premium", quantity: 1 }]), /Invalid ticket tier/);
  assert.throws(() => calculateOrderTotals([{ tier: "early", quantity: 0 }]), /Invalid ticket tier/);
  assert.throws(() => calculateOrderTotals([]), /Select at least one ticket/);
});
