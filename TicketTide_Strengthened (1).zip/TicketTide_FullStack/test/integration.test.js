const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "tickettide-test-"));
process.env.DB_FILE = path.join(tempDir, "test.sqlite");
process.env.JWT_SECRET = "test_jwt_secret_at_least_32_characters_long";
process.env.QR_SIGNING_SECRET = "test_qr_secret_at_least_32_characters_long";
process.env.ADMIN_API_KEY = "test_admin_key_at_least_32_characters";
const { app, db, reserveInventory, releaseReservations } = require("../server");

let server, baseUrl;
before(async () => {
  server = app.listen(0);
  await new Promise(resolve => server.once("listening", resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});
after(async () => {
  await new Promise(resolve => server.close(resolve));
  db.close();
  fs.rmSync(tempDir, { recursive: true, force: true });
});

test("health endpoint reports API and database availability", async () => {
  const response = await fetch(`${baseUrl}/api/health`);
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.ok, true);
  assert.equal(body.database, "connected");
});

test("protected ticket API rejects requests without authentication", async () => {
  const response = await fetch(`${baseUrl}/api/tickets/mine`);
  assert.equal(response.status, 401);
  assert.match((await response.json()).error, /Authentication required/);
});

test("inventory endpoint exposes seeded stock", async () => {
  const response = await fetch(`${baseUrl}/api/inventory`);
  assert.equal(response.status, 200);
  const { inventory } = await response.json();
  assert.equal(inventory.find(row => row.tier === "early").available, 100);
});

test("inventory reservation atomically decrements stock", () => {
  const before = db.prepare("SELECT available FROM inventory WHERE tier='early'").get().available;
  reserveInventory("payment-unit-1", [{ tier: "early", quantity: 3 }]);
  const after = db.prepare("SELECT available FROM inventory WHERE tier='early'").get().available;
  assert.equal(after, before - 3);
});

test("overselling is rejected and transaction rolls back all tier changes", () => {
  const earlyBefore = db.prepare("SELECT available FROM inventory WHERE tier='early'").get().available;
  const vipBefore = db.prepare("SELECT available FROM inventory WHERE tier='vip'").get().available;
  assert.throws(
    () => reserveInventory("payment-unit-2", [
      { tier: "early", quantity: 2 },
      { tier: "vip", quantity: vipBefore + 1 }
    ]),
    /Insufficient inventory/
  );
  assert.equal(db.prepare("SELECT available FROM inventory WHERE tier='early'").get().available, earlyBefore);
  assert.equal(db.prepare("SELECT available FROM inventory WHERE tier='vip'").get().available, vipBefore);
});

test("releasing a reservation restores stock exactly once", () => {
  const before = db.prepare("SELECT available FROM inventory WHERE tier='general'").get().available;
  reserveInventory("payment-unit-3", [{ tier: "general", quantity: 4 }]);
  releaseReservations("payment-unit-3");
  releaseReservations("payment-unit-3");
  const after = db.prepare("SELECT available FROM inventory WHERE tier='general'").get().available;
  assert.equal(after, before);
});
