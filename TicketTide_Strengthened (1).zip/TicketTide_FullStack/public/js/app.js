const API = (window.TICKETTIDE_API || "").replace(/\/$/, "");
const token = () => localStorage.getItem("tt_access_token");
const authHeaders = () => ({ "Content-Type":"application/json", ...(token()?{Authorization:`Bearer ${token()}`}:{}) });
const cash = n => "₹"+Number(n||0).toLocaleString("en-IN");
async function api(path, options={}) {
  const res = await fetch(API+path, { ...options, headers:{...authHeaders(),...(options.headers||{})} });
  const data = await res.json().catch(()=>({error:"Unexpected server response"}));
  if(!res.ok) throw new Error(data.error || "Request failed");
  return data;
}
function message(el, text, ok=false){ if(!el)return; el.className="form-message "+(ok?"success":"error");el.textContent=text; }

// Mobile navigation and event filters.
const menu=document.querySelector(".menu-toggle"),nav=document.querySelector(".main-nav");
if(menu&&nav)menu.addEventListener("click",()=>nav.classList.toggle("open"));
const search=document.getElementById("eventSearch"),filter=document.getElementById("eventFilter");
function filterEvents(){document.querySelectorAll(".searchable").forEach(c=>{c.style.display=c.dataset.name.toLowerCase().includes((search?.value||"").toLowerCase())&&(filter?.value==="all"||c.dataset.category===filter.value)?"":"none";});}
if(search)search.addEventListener("input",filterEvents);if(filter)filter.addEventListener("change",filterEvents);

// Cart remains a browser selection; price/inventory are revalidated by server.
const priceMap={early:799,general:1299,vip:2499}, names={early:"Early Bird",general:"General Admission",vip:"VIP Backstage"};
const readCart=()=>{try{return JSON.parse(sessionStorage.getItem("ttCart")||"{}")}catch{return {}}};
const writeCart=c=>sessionStorage.setItem("ttCart",JSON.stringify(c));
function totals(c){let sub=Object.keys(priceMap).reduce((s,k)=>s+(Number(c[k])||0)*priceMap[k],0),qty=Object.values(c).reduce((s,n)=>s+(Number(n)||0),0),fee=qty*30,tax=Math.round(sub*.05);return{sub,fee,tax,total:sub+fee+tax,qty};}
function renderCart(){
 const c=readCart(),t=totals(c);
 Object.keys(priceMap).forEach(k=>{let q=document.getElementById(k+"Qty"),l=document.getElementById(k+"Left");if(q)q.textContent=c[k]||0;if(l)l.textContent=({early:24,general:86,vip:12}[k]-(c[k]||0));});
 const items=document.getElementById("summaryItems");if(items){let ks=Object.keys(priceMap).filter(k=>c[k]>0);items.innerHTML=ks.length?ks.map(k=>`<div class="summary-item"><span>${names[k]} × ${c[k]}</span><b>${cash(priceMap[k]*c[k])}</b></div>`).join(""):"Choose a ticket to get started.";}
 [["subtotal",t.sub],["fee",t.fee],["tax",t.tax],["total",t.total]].forEach(([id,v])=>{let e=document.getElementById(id);if(e)e.textContent=cash(v)});
 let b=document.getElementById("checkoutBtn");if(b)b.disabled=!t.qty;
}
document.querySelectorAll(".quantity button").forEach(b=>b.addEventListener("click",()=>{let c=readCart(),k=b.dataset.tier;c[k]=Math.max(0,Math.min(({early:24,general:86,vip:12}[k]),(c[k]||0)+Number(b.dataset.step)));writeCart(c);renderCart();}));
renderCart();
document.getElementById("checkoutBtn")?.addEventListener("click",()=>location.href="checkout.html");

// Checkout: OTP verification -> Razorpay order -> server-side signature verification.
const checkoutItems=document.getElementById("checkoutItems");
if(checkoutItems){const c=readCart(),t=totals(c);checkoutItems.innerHTML=Object.keys(priceMap).filter(k=>c[k]>0).map(k=>`<div class="summary-item"><span>${names[k]} × ${c[k]}</span><b>${cash(priceMap[k]*c[k])}</b></div>`).join("")||"No tickets selected.";[["checkoutSubtotal",t.sub],["checkoutFee",t.fee],["checkoutTax",t.tax],["checkoutTotal",t.total]].forEach(([id,v])=>{let e=document.getElementById(id);if(e)e.textContent=cash(v)});}
let verified=false;
const checkoutForm=document.getElementById("checkoutForm");
if(checkoutForm){
 const email=checkoutForm.querySelector('input[name="email"]');
 const name=checkoutForm.querySelector('input[name="name"]');
 const otpWrap=document.createElement("div");otpWrap.innerHTML=`<label>Student email OTP<input id="studentOtp" inputmode="numeric" maxlength="6" placeholder="Enter 6-digit OTP"></label><button class="btn btn-outline btn-block" type="button" id="verifyOtpBtn">Verify email OTP</button><div id="otpMessage" class="form-message"></div>`;
 const send=document.createElement("button");send.type="button";send.className="btn btn-outline btn-block";send.textContent="Send verification OTP";send.id="sendOtpBtn";
 const pay=document.createElement("button");pay.type="button";pay.className="btn btn-primary btn-block";pay.textContent="Verify & pay securely ↗";pay.id="payNowBtn";pay.disabled=true;
 const info=document.createElement("div");info.className="info-note";info.textContent="Verify your .edu or .ac.in student email to continue. Payment uses Razorpay test mode when configured.";
 const submit=checkoutForm.querySelector('button[type="submit"]');if(submit)submit.remove();
 checkoutForm.append(info,send,otpWrap,pay);
 send.addEventListener("click",async()=>{try{const studentEmail=checkoutForm.querySelector('input[name="studentEmail"]').value.trim()||email.value.trim();const d=await api("/api/auth/send-otp",{method:"POST",body:JSON.stringify({name:name.value,email:studentEmail})});message(document.getElementById("otpMessage"),d.message||"OTP sent. Check your email.",true);}catch(e){message(document.getElementById("otpMessage"),e.message)}});
 document.getElementById("verifyOtpBtn").addEventListener("click",async()=>{try{const studentEmail=checkoutForm.querySelector('input[name="studentEmail"]').value.trim()||email.value.trim();const d=await api("/api/auth/verify-otp",{method:"POST",body:JSON.stringify({name:name.value,email:studentEmail,otp:document.getElementById("studentOtp").value})});localStorage.setItem("tt_access_token",d.token);localStorage.setItem("tt_user",JSON.stringify(d.user));verified=true;pay.disabled=false;message(document.getElementById("otpMessage"),"Student email verified successfully.",true);}catch(e){message(document.getElementById("otpMessage"),e.message)}});
 pay.addEventListener("click",async()=>{try{if(!verified&&!token())throw new Error("Verify your student email first.");const c=readCart(),items=Object.keys(priceMap).filter(k=>c[k]>0).map(k=>({tier:k,quantity:c[k]}));if(!items.length)throw new Error("Select tickets before checkout.");const order=await api("/api/payments/create-order",{method:"POST",body:JSON.stringify({items})});if(!window.Razorpay)throw new Error("Razorpay checkout script did not load. Check your internet connection.");const rzp=new Razorpay({key:order.keyId,amount:order.amount,currency:order.currency,name:"TicketTide",description:"Campus Music Fest 2026",order_id:order.orderId,prefill:{name:name.value,email:checkoutForm.querySelector('input[name="studentEmail"]').value||email.value},theme:{color:"#8758f4"},handler:async response=>{try{await api("/api/payments/verify",{method:"POST",body:JSON.stringify(response)});sessionStorage.removeItem("ttCart");alert("Payment verified! Your tickets are ready in My Tickets.");location.href="my-tickets.html";}catch(e){alert("Payment verification failed: "+e.message)}}});rzp.on("payment.failed",resp=>message(document.getElementById("otpMessage"),resp.error?.description||"Payment failed. Please retry."));rzp.open();}catch(e){message(document.getElementById("otpMessage"),e.message)}});
}

// Ticket wallet: request short-lived QR from backend and refresh every 30 seconds.
async function loadWallet(){
 const holder=document.getElementById("holderName");if(!holder)return;
 try{
  if(!token())throw new Error("Please complete student verification and a successful booking first.");
  const data=await api("/api/tickets/mine");
  if(!data.tickets.length)throw new Error("No tickets found for this verified account yet.");
  const ticket=data.tickets[0];holder.textContent=data.user.name||data.user.email;
  const details=document.querySelector(".pass-details");if(details)details.innerHTML=`<span class="tiny-label">${ticket.eventDate||"EVENT PASS"}</span><h2>${ticket.eventName||"Campus Music Fest 2026"}</h2><div class="pass-meta"><span>📍 ${ticket.venue||"Hyderabad"}</span><span>◷ ${ticket.tier}</span><span>PASS · ${ticket.id.slice(0,8).toUpperCase()}</span></div>`;
  async function refresh(){try{const q=await api(`/api/tickets/${ticket.id}/qr`);const pattern=document.getElementById("qrPattern");if(pattern){pattern.style.background="white";pattern.style.backgroundImage=`url('${q.qrDataUrl}')`;pattern.style.backgroundSize="contain";pattern.style.backgroundRepeat="no-repeat";}document.getElementById("qrCodeText").textContent=q.tokenPreview;const copyBtn=document.getElementById("copyQrToken");if(copyBtn){copyBtn.dataset.token=q.token;copyBtn.disabled=false;}let left=30;const count=document.getElementById("qrCountdown"),bar=document.getElementById("countdownBar");if(window.ttQrTimer)clearInterval(window.ttQrTimer);count.textContent=left;bar.style.width="100%";window.ttQrTimer=setInterval(()=>{left--;count.textContent=left;bar.style.width=(left/30*100)+"%";if(left<=0){clearInterval(window.ttQrTimer);refresh();}},1000);}catch(e){message(document.querySelector(".wallet-side .panel-card"),e.message)}}
  await refresh();
 }catch(e){const wallet=document.querySelector(".wallet-layout");if(wallet){const note=document.createElement("div");note.className="info-note";note.textContent=e.message;wallet.prepend(note);}}
}
loadWallet();

// Transfers use a verified recipient OTP. Send and complete are explicit backend actions.
const transferForm=document.getElementById("transferForm");
if(transferForm){
 const original=transferForm.innerHTML;
 transferForm.innerHTML=`<label>Recipient student email<input required type="email" id="recipientEmail" placeholder="friend@college.ac.in"></label><button class="btn btn-outline btn-block" type="button" id="sendTransferOtp">Send recipient OTP</button><label>Recipient OTP<input id="recipientOtp" inputmode="numeric" maxlength="6" placeholder="6-digit OTP"></label><button class="btn btn-primary btn-block" type="submit">Verify & transfer ticket ↗</button>`;
 document.getElementById("sendTransferOtp").addEventListener("click",async()=>{try{let d=await api("/api/transfers/send-otp",{method:"POST",body:JSON.stringify({email:document.getElementById("recipientEmail").value})});message(document.getElementById("transferMessage"),d.message,true)}catch(e){message(document.getElementById("transferMessage"),e.message)}});
 transferForm.addEventListener("submit",async e=>{e.preventDefault();try{const tickets=await api("/api/tickets/mine");const t=tickets.tickets[0];if(!t)throw new Error("No active ticket to transfer.");const d=await api("/api/transfers/complete",{method:"POST",body:JSON.stringify({ticketId:t.id,email:document.getElementById("recipientEmail").value,otp:document.getElementById("recipientOtp").value})});message(document.getElementById("transferMessage"),d.message,true)}catch(err){message(document.getElementById("transferMessage"),err.message)}});
}

// Resale API listing and price-cap validation.
const resaleForm=document.getElementById("resaleForm");
if(resaleForm){
 const face=document.getElementById("faceValue"),price=document.getElementById("resalePrice"),cap=document.getElementById("capValue");
 const update=()=>{if(cap)cap.textContent=cash(face?.value||0)};face?.addEventListener("input",update);update();
 resaleForm.addEventListener("submit",async e=>{e.preventDefault();try{const d=await api("/api/resale/list",{method:"POST",body:JSON.stringify({eventName:resaleForm.querySelector('input[type="text"],input:not([type])')?.value||"Campus Music Fest 2026",faceValue:Number(face.value),price:Number(price.value)})});message(document.getElementById("resaleMessage"),d.message,true)}catch(err){message(document.getElementById("resaleMessage"),err.message)}});
}
document.querySelectorAll(".buy-resale").forEach(b=>b.addEventListener("click",()=>alert("Sign in with a verified student account to purchase a resale ticket.")));

// Organizer scan endpoint. Protect with ADMIN_API_KEY configured on server; key is entered by organizer.
const scanForm=document.getElementById("scanForm");
if(scanForm)scanForm.addEventListener("submit",async e=>{e.preventDefault();const code=document.getElementById("scanCode").value.trim();const key=prompt("Enter organizer scan key configured by your administrator:");if(!key)return;try{const d=await fetch(API+"/api/admin/scan",{method:"POST",headers:{"Content-Type":"application/json","x-admin-key":key},body:JSON.stringify({token:code})}).then(async r=>{let x=await r.json();if(!r.ok)throw new Error(x.error);return x});message(document.getElementById("scanMessage"),d.message,true);const c=document.getElementById("checkinCount");if(c)c.textContent=Number(c.textContent||0)+1;}catch(err){message(document.getElementById("scanMessage"),err.message)}});

const copyQrToken=document.getElementById("copyQrToken");
if(copyQrToken)copyQrToken.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(copyQrToken.dataset.token||"");copyQrToken.textContent="Token copied";setTimeout(()=>copyQrToken.textContent="Copy scanner token",1800);}catch{message(document.querySelector(".wallet-side .panel-card"),"Clipboard access unavailable. Use the QR image with a QR reader to copy its token.");}});
