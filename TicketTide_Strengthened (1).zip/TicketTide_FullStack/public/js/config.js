window.TICKETTIDE_API = ""; // Same-origin API. Change only if frontend and API are hosted separately.
